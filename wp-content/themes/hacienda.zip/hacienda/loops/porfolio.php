<section class="blog-me pt-100 py-2 wow fadeInDown" data-wow-delay="1s" id="blog" style="background: #fff">
      
      <div class="container">

          <div class="col-xl-6 mx-auto text-center">
               <br>
               <div class="section-title mb-100">
                  <h4>Organos Bajo Tutela</h4>
               </div>
          </div>
         <div class="row">
           <div class="col-md-8 col-sm-12 co-xs-12 gal-item">
               <div class="row h-50">
                    <div class="col-md-12 col-sm-12 co-xs-12 gal-item">
                           <div class="box imagebox">
                         <!--<img src="http://fakeimg.pl/758x370/" class="img-ht img-fluid rounded">-->
                         <a href="">
                         <img src="<?php echo get_template_directory_uri(); ?>/img/tesoreria.jpg"  alt="yo" class="img-ht category-banner img-responsive " alt="Responsive image"/>
                        </a>
                         <span class="imagebox-desc">Tesoreria General del estado</span>
                           </div>
                     </div>
               </div>
           
             <!--<div class="row ">
                   <div class="col-md-6 col-sm-6 co-xs-12 gal-item">
                    <div class="box">
                     <img src="http://fakeimg.pl/748x177/" class="img-ht img-fluid rounded">
                  </div>
                  </div>

                  <div class="col-md-6 col-sm-6 co-xs-12 gal-item">
                   <div class="box">
                     <img src="http://fakeimg.pl/371x370/" class="img-ht img-fluid rounded">
                  </div>
                  </div>
                  </div>-->
            </div>

                 <div class="col-md-4 col-sm-6 co-xs-12 gal-item">
                     <!--inicio col-md-4-->
                     <div class="col-md-12 gal-item h-50">
                        <div class="box">
                           <img src="http://fakeimg.pl/748x177/" class="img-ht img-fluid rounded">
                        </div>
                     </div>

                      <div class="col-md-12 gal-item h-50">
                        <div class="box">
                           <img src="http://fakeimg.pl/748x177/" class="img-ht img-fluid rounded">
                        </div>
                     </div>
                      

                     

                  </div>

         </div>
         <br/>
      </div>
               
          
      <!--<div class="site-space"><br></div>-->
   </section>
