
<a href="#openModal"><i class="fa fa-search test"></i></a>

<div id="openModal" class="modalDialog">
  <div>
    <a href="#" title="cerrar" class="close">X</a>
    <h2></h2>
    <form class="form-inline my-2 my-lg-0">
      <input class="form-control mr-sm-2" type="search" placeholder="Buscar en el sitio.." aria-label="Search">
      <button class="btn btn-outline-success my-2 my-sm-0" type="submit">Buscar</button>
    </form>
  </div>
</div>
