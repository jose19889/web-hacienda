<section id="our-process" class="padding py-3  wow fadeInUp" data-wow-delay="300ms" style="background: #fbfbfb;" >
      <div class="container">
	<div class="row mb-5 mt-5">
	<div class=" col-sm-4">
	<div class="wrimagecard wrimagecard-topimage">
          <a href="#">
          <div class="wrimagecard-topimage_header" style="background-color:rgba(193, 196, 199, 0.1) ">
            <center><i class="fa fa-area-chart" style="color:#5a6268"></i></center>
          </div>
          <div class="wrimagecard-topimage_title text-center">
            <h4>Presupuesto General del Estado
            <div class="pull-right badge"></div></h4>
          </div>
        </a>
      </div>
      </div>
    <div class=" col-sm-4">
      <div class="wrimagecard wrimagecard-topimage">
          <a href="#">
          <div class="wrimagecard-topimage_header" style="background-color: rgba(193, 196, 199, 0.1)">
            <center><i class = "fa fa-cubes" style="color:#5a6268"></i></center>
          </div>
          <div class="wrimagecard-topimage_title">
            <h4>Documentacion
            <div class="pull-right badge" id="WrControls"></div></h4>
          </div>
        </a>
      </div>
</div>
<div class=" col-sm-4">
      <div class="wrimagecard wrimagecard-topimage">
          <a href="#">
          <div class="wrimagecard-topimage_header" style="background-color:  rgba(193, 196, 199, 0.1)">
            <center><i class="fa fa-pencil-square-o" style="color:#5a6268"> </i></center>
          </div>
          <div class="wrimagecard-topimage_title" >
            <h4>Cartas y Memorandums
            <div class="pull-right badge" id="WrForms"></div>
            </h4>
          </div>
          
        </a>
      </div>
	</div>
	

	
</div>
</div>
</section>