
 <section class="blog-me pt-100 py-2  wow fadeInUp " data-wow-duration="4s" id="blog" style="background: #f9f9f9;">
         <div class="container">
            
            <div class="row">
               <div class="col-xl-6 mx-auto text-center">
                  <div class="site-space"><br></div>
                  <div class="section-title mb-100">
                     <h4>Servicios</h4>
                  </div>
               </div>
            </div>
            <div class="row">
               <div class="col-lg-4 col-md-6">
                  <!-- Single Blog -->
                  <div class="single-blog">
                     
                     <div class="blog-content">
                        <div class="blog-title">
                           <h4><a href="#">Auditoria</a></h4>
                           <div class="meta">
                              <ul>
                                 <li></li>
                              </ul>
                           </div>
                        </div>
                        <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Maecenas in pulvinar neque.</p>
                       
                        <p><a class="btn btn-secondary" href="#" role="button">View details &raquo;</a></p>
                     </div>
                  </div>
               </div>
               <div class="col-lg-4 col-md-6">
                  <!-- Single Blog -->
                  <div class="single-blog">
                     
                     <div class="blog-content">
                        <div class="blog-title">
                           <h4><a href="#">Formacion</a></h4>
                           <div class="meta">
                              <ul>
                                 <li></li>
                              </ul>
                           </div>
                        </div>
                        <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Maecenas in pulvinar neque.</p>
                       <p><a class="btn btn-secondary" href="#" role="button">View details &raquo;</a></p>
                     </div>
                  </div>
               </div>
               <div class="col-lg-4 col-md-6">
                  <!-- Single Blog -->
                  <div class="single-blog">
                     
                     <div class="blog-content">
                        <div class="blog-title">
                           <h4><a href="#">gestion comercial</a></h4>
                           <div class="meta">
                              <ul>
                                 <li></li>
                              </ul>
                           </div>
                        </div>
                        <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Maecenas in pulvinar neque.</p>
                       <p><a class="btn btn-secondary" href="#" role="button">View details &raquo;</a></p>
                     </div>
                  </div>
               </div>
            </div>
            <br>
            <!--blog 2-->
             <div class="row">
               <div class="col-lg-4 col-md-6">
                  <!-- Single Blog -->
                  <div class="single-blog">
                     
                     <div class="blog-content">
                        <div class="blog-title">
                           <h4><a href="#">Auditoria</a></h4>
                           <div class="meta">
                              <ul>
                                 <li></li>
                              </ul>
                           </div>
                        </div>
                        <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Maecenas in pulvinar neque.</p>
                       
                        <p><a class="btn btn-secondary" href="#" role="button">View details &raquo;</a></p>
                     </div>
                  </div>
               </div>
               <div class="col-lg-4 col-md-6">
                  <!-- Single Blog -->
                  <div class="single-blog">
                     
                     <div class="blog-content">
                        <div class="blog-title">
                           <h4><a href="#">Formacion</a></h4>
                           <div class="meta">
                              <ul>
                                 <li></li>
                              </ul>
                           </div>
                        </div>
                        <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Maecenas in pulvinar neque.</p>
                       <p><a class="btn btn-secondary" href="#" role="button">View details &raquo;</a></p>
                     </div>
                  </div>
               </div>
               <div class="col-lg-4 col-md-6">
                  <!-- Single Blog -->
                  <div class="single-blog">
                     
                     <div class="blog-content">
                        <div class="blog-title">
                           <h4><a href="#">gestion comercial</a></h4>
                           <div class="meta">
                              <ul>
                                 <li></li>
                              </ul>
                           </div>
                        </div>
                        <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Maecenas in pulvinar neque.</p>
                       <p><a class="btn btn-secondary" href="#" role="button">View details &raquo;</a></p>
                     </div>
                  </div>
               </div>
            </div>
            <!--end blog 2-->
         </div>
         <div class="site-space"><br></div>
      </section>
