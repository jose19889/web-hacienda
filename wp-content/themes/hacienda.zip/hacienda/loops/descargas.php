
        <div class="col-md-4">
            <ul class="list-unstyled pt-5">
                   <li class="media mb-3 border border-left-0 border-top-0 border-right-0 pb-2">
                    <img class="mr-3 pt-1" src="<?php echo get_template_directory_uri(); ?>/img/icon_adobe.png" width="" height="" alt="" /> 
                    <div class="media-body">
                      <a href="#"><h6 class="mt-0 mb-1 text-descargas">Ley Número 8/ 2017, de fecha 20 de noviembre, de los Presupuestos Generales del Estado para el Ejercicio Económico 2018.</h6></a>
                       <button type="button" class="btn btn-secondary"><i class="fa fa-download"></i> descargar</button>
                    </div>
                  </li>
                  <li class="media mb-3 border border-left-0 border-top-0 border-right-0 pb-2">
                    <img class="mr-3 pt-1" src="<?php echo get_template_directory_uri(); ?>/img/icon_adobe.png" width="" height="" alt="" /> 
                    <div class="media-body">
                      <a href="#"><h6 class="mt-0 mb-1 text-descargas">Ley Número 8/ 2017, de fecha 20 de noviembre, de los Presupuestos Generales del Estado para el Ejercicio Económico 2018.</h6></a>
                       <button type="button" class="btn btn-secondary"><i class="fa fa-download"></i> descargar</button>
                    </div>
                  </li>
                  <li class="media mb-4 border border-left-0 border-top-0 border-right-0 pb-2">
                   <img class="mr-3 pt-1" src="<?php echo get_template_directory_uri(); ?>/img/icon_adobe.png" width="" height="" alt="" /> 
                    <div class="media-body">
                      <a href="#"><h6 class="mt-0 mb-1 text-descargas">Ley Número 8/ 2017, de fecha 20 de noviembre, de los Presupuestos Generales del Estado para el Ejercicio Económico 2018.</h6></a>
                   <button type="button" class="btn btn-secondary"><i class="fa fa-download"></i> descargar</button>
                    </div>
                  </li>
              
                </ul>
        </div>
