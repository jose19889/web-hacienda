<aside class="sidebar">
  <?php dynamic_sidebar('sidebar-widget-area'); ?>
</aside>
